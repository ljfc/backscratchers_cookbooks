Chef::Log.info("The Backscratchers default recipe called (note: it does nothing)")
