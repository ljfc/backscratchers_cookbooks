# Poise-Ruby-Build Changelog

## v1.0.1

* Install bundler in the same way as other `ruby_runtime` providers.
* New integration test harness.

## v1.0.0

* Initial release!

