Chef::Log.info("The Backscratchers deploy recipe called")


