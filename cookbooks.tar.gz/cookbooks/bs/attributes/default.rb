default['thingy'] = 'bob'
