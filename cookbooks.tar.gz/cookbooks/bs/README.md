# backscratchers_cookbooks
Chef cookbooks for deploying The Backscratchers site on AWS OpsWorks
