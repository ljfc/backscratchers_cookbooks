# Poise-Javascript Changelog

## v1.0.1

* Update for Chef 12.6 compatibility.
* Update version list for `nodejs` provider.

## v1.0.0

* Initial release!

